# tc2
Scripts de ejemplo en Python para arrancar a simular funciones para la materia Teoría de Circuitos 2
